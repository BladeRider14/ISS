package Persistence.Exception;

public class RepositoryException extends Exception {
    public RepositoryException(String message) {
        super((message));
    }
}
