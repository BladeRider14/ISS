package Model;

public enum UserType {
    ADMIN,SUBSCRIBER,LIBRARIAN
}
